X = [10 ^ -10 10 ^ -12 10 ^ - 14 10 ^ -16];
A = [X ; f_2(X) ; f_3(X) ; f_4(X)]
format long;
format long e;
A
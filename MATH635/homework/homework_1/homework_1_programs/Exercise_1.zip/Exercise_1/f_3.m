function y = f_3(x)
y = 1 ./ (sqrt(1 + x) + 1);
end
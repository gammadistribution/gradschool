function y = f_2(x)
y = (sqrt(1 + x) - 1) ./ x;
end
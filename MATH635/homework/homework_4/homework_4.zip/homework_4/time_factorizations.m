dimensions = 60;
iterations = 100;

time_qr_factor(dimensions, iterations);
time_eig_values(dimensions, 5, 0);
